
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 31/10/2024
// Versão Código: 0.0.0.1v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Paint House 0.0.0.1v - Metragem e Calculo para Pintura Residencial, com interface grafica e compilacao em ambiente desktop.

package phreplit;

					import java.awt.EventQueue;

					import javax.swing.JFrame;
					import java.awt.CardLayout;
					import java.awt.GridBagLayout;
					import javax.swing.JPanel;
					import javax.swing.JTabbedPane;
					import java.awt.Window.Type;
					import javax.swing.border.BevelBorder;
					import java.awt.SystemColor;
					import javax.swing.border.TitledBorder;
					import javax.swing.border.EtchedBorder;
					import java.awt.Color;
					import java.awt.Toolkit;
					import java.awt.Label;
					import java.awt.Panel;
					import javax.swing.JTextField;
					import javax.swing.JButton;
					import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

					@SuppressWarnings("unused")
					public class PaintHouse {

						private JFrame frmPaintHouse;
						private JTextField textField;
						private JTextField textField_1;
						private JTextField textField_2;
						private JTextField textField_3;
						private JTextField textField_4;
						private JTextField textField_5;
						private JTextField textField_6;
						private JTextField textField_7;
						private JTextField textField_8;
						private JTextField textField_12;
						private JTextField textField_15;
						private JTextField textField_16;
						private JTextField textField_17;
						private JTextField textField_18;

						/**
						 * Launch the application.
						 */
						public static void main(String[] args) {
							EventQueue.invokeLater(new Runnable() {
								public void run() {
									try {
										PaintHouse window = new PaintHouse();
										window.frmPaintHouse.setVisible(true);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							});
						}

						/**
						 * Create the application.
						 */
						public PaintHouse() {
							initialize();
						}

						/**
						 * Initialize the contents of the frame.
						 */
						private void initialize() {
							frmPaintHouse = new JFrame();
							frmPaintHouse.setIconImage(Toolkit.getDefaultToolkit().getImage(PaintHouse.class.getResource("/phreplit/logo_40px.png")));
							frmPaintHouse.getContentPane().setBackground(SystemColor.activeCaption);
							frmPaintHouse.setForeground(SystemColor.activeCaption);
							frmPaintHouse.setTitle("Sistema - Paint House - 0.0.0.1v - Metragem e Calculo para Pintura Residencial");
							frmPaintHouse.setResizable(false);
							frmPaintHouse.setBounds(100, 100, 860, 581);
							frmPaintHouse.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
							frmPaintHouse.getContentPane().setLayout(null);
							
							JPanel panel = new JPanel();
							panel.setBackground(SystemColor.activeCaption);
							panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "1. Calcular Metro Quad. de uma Parede", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
							panel.setBounds(10, 10, 270, 282);
							frmPaintHouse.getContentPane().add(panel);
							panel.setLayout(null);
							
							textField = new JTextField();
							textField.setBounds(10, 56, 181, 19);
							panel.add(textField);
							textField.setColumns(10);
							
							textField_1 = new JTextField();
							textField_1.setBounds(10, 105, 181, 19);
							panel.add(textField_1);
							textField_1.setColumns(10);
							
							textField_2 = new JTextField();
							textField_2.setBounds(10, 152, 181, 19);
							panel.add(textField_2);
							textField_2.setColumns(10);
							
							JButton btnNewButton = new JButton("Calcular");
							btnNewButton.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int mult = Integer.parseInt(textField.getText())*Integer.parseInt(textField_1.getText());
									textField_2.setText(String.valueOf(mult));
								}
							});
							btnNewButton.setBounds(10, 184, 85, 21);
							panel.add(btnNewButton);
							
							JButton btnNewButton_1 = new JButton("Resetar");
							btnNewButton_1.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField.setText("");
									textField_1.setText("");
									textField_2.setText("");
								}
							});
							btnNewButton_1.setBounds(106, 184, 85, 21);
							panel.add(btnNewButton_1);
							
							JLabel lblNewLabel = new JLabel("Digite a altura da parede.:");
							lblNewLabel.setBounds(10, 33, 181, 13);
							panel.add(lblNewLabel);
							
							JLabel lblNewLabel_1 = new JLabel("Digite a largura da parede.:");
							lblNewLabel_1.setBounds(10, 82, 181, 13);
							panel.add(lblNewLabel_1);
							
							JLabel lblNewLabel_2 = new JLabel("Resultado - A parede tem (n) M²(s).:");
							lblNewLabel_2.setBounds(10, 129, 250, 13);
							panel.add(lblNewLabel_2);
							
							JPanel panel_4 = new JPanel();
							panel_4.setBackground(SystemColor.activeCaption);
							panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "3. Calc. Quantidade de Demaos por Lata(s)", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
							panel_4.setBounds(10, 302, 270, 232);
							frmPaintHouse.getContentPane().add(panel_4);
							panel_4.setLayout(null);
							
							JLabel lblNewLabel_12 = new JLabel("Digite a quantidade de latas de tinta ");
							lblNewLabel_12.setBounds(10, 22, 250, 13);
							panel_4.add(lblNewLabel_12);
							
							JLabel lblNewLabel_15 = new JLabel("Resultado - A quantidade de demaos");
							lblNewLabel_15.setBounds(10, 89, 225, 13);
							panel_4.add(lblNewLabel_15);
							
							JLabel lblNewLabel_16 = new JLabel("por (n) lata(s) de tinta ");
							lblNewLabel_16.setBounds(10, 112, 180, 13);
							panel_4.add(lblNewLabel_16);
							
							JLabel lblNewLabel_17 = new JLabel("sera de (n) demao(s).:");
							lblNewLabel_17.setBounds(10, 135, 180, 13);
							panel_4.add(lblNewLabel_17);
							
							textField_12 = new JTextField();
							textField_12.setBounds(10, 60, 180, 19);
							panel_4.add(textField_12);
							textField_12.setColumns(10);
							
							textField_15 = new JTextField();
							textField_15.setBounds(10, 158, 180, 19);
							panel_4.add(textField_15);
							textField_15.setColumns(10);
							
							JButton btnNewButton_8 = new JButton("Calcular");
							btnNewButton_8.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int var4 = 3;
									int mult3 = Integer.parseInt(textField_12.getText())*(var4);
									textField_15.setText(String.valueOf(mult3));  
								}
							});
							btnNewButton_8.setBounds(10, 187, 85, 21);
							panel_4.add(btnNewButton_8);
							
							JButton btnNewButton_9 = new JButton("Resetar");
							btnNewButton_9.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField_12.setText("");
									textField_15.setText("");
								}
							});
							btnNewButton_9.setBounds(105, 187, 85, 21);
							panel_4.add(btnNewButton_9);
							
							JLabel lblNewLabel_11 = new JLabel("obtidas por M².:");
							lblNewLabel_11.setBounds(10, 37, 180, 13);
							panel_4.add(lblNewLabel_11);
							
							JPanel panel_5 = new JPanel();
							panel_5.setBackground(SystemColor.activeCaption);
							panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "4. Calcular Quantidade de Demaos por M\u00B2", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
							panel_5.setBounds(290, 302, 264, 232);
							frmPaintHouse.getContentPane().add(panel_5);
							panel_5.setLayout(null);
							
							JLabel lblNewLabel_13 = new JLabel("Digite a quantidade de latas de tinta");
							lblNewLabel_13.setBounds(10, 22, 244, 13);
							panel_5.add(lblNewLabel_13);
							
							JLabel lblNewLabel_18 = new JLabel("Resultado - A quantidade de demaos");
							lblNewLabel_18.setBounds(10, 84, 244, 13);
							panel_5.add(lblNewLabel_18);
							
							JLabel lblNewLabel_19 = new JLabel("...sera de (n) demao(s).:");
							lblNewLabel_19.setBounds(10, 141, 175, 13);
							panel_5.add(lblNewLabel_19);
							
							JLabel lblNewLabel_20 = new JLabel("para pintar (n) metros quadrados...");
							lblNewLabel_20.setBounds(10, 95, 244, 13);
							panel_5.add(lblNewLabel_20);
							
							textField_16 = new JTextField();
							textField_16.setBounds(10, 58, 175, 19);
							panel_5.add(textField_16);
							textField_16.setColumns(10);
							
							textField_17 = new JTextField();
							textField_17.setBounds(10, 118, 175, 19);
							panel_5.add(textField_17);
							textField_17.setColumns(10);
							
							textField_18 = new JTextField();
							textField_18.setBounds(10, 154, 175, 19);
							panel_5.add(textField_18);
							textField_18.setColumns(10);
							
							JButton btnNewButton_10 = new JButton("Calcular");
							btnNewButton_10.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int v2 = 3; // 3600ml(3,6) dividido por 3 sera 1200ml equivale a 3 demaos
					                int mq1 = 360; // 1 metro quadrado
					                int lata1 = 3600; // 1 lata de tinta
					                int resultado4 = Integer.parseInt(textField_16.getText())*(v2);
					                int calcqtdlitro = Integer.parseInt(textField_16.getText())*(lata1);
					                int calcmq = calcqtdlitro / mq1;  // metro quadrado
					                textField_17.setText(String.valueOf(calcmq));
					                textField_18.setText(String.valueOf(resultado4));
								}
							});
							btnNewButton_10.setBounds(10, 183, 85, 21);
							panel_5.add(btnNewButton_10);
							
							JButton btnNewButton_11 = new JButton("Resetar");
							btnNewButton_11.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField_16.setText("");
									textField_17.setText("");
									textField_18.setText("");
								}
							});
							btnNewButton_11.setBounds(100, 183, 85, 21);
							panel_5.add(btnNewButton_11);
							
							JLabel lblNewLabel_14 = new JLabel("obtidas por M².:");
							lblNewLabel_14.setBounds(10, 35, 244, 13);
							panel_5.add(lblNewLabel_14);
							
							JPanel panel_7 = new JPanel();
							panel_7.setBackground(SystemColor.activeCaption);
							panel_7.setBorder(new TitledBorder(null, "Setup", TitledBorder.LEADING, TitledBorder.TOP, null, null));
							panel_7.setBounds(564, 302, 270, 232);
							frmPaintHouse.getContentPane().add(panel_7);
							panel_7.setLayout(null);
							
							JButton btnNewButton_14 = new JButton("Info");
							btnNewButton_14.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									JOptionPane.showMessageDialog(
											null,"Info\n"
								            + "\nEste software foi desenvolvido com variaveis inteiras entao nao aceita numeros com virgula ex: 2,90 metros mude para 3 metros.\n"
								            + "\nPara calcular a Area de Muro ou Parede [Metro Quadrado] - Muro ou Parede de Tamanho Regular [4 lados iguais] - iremos calcular a altura vezes a largura.\n"
								            + "\n Para Calcular Pintura com Tinta sem diluicao:\n"
								            + "\n Com base em uma lata de tinta de 3,6L e com base em uma parede com (A 2,70 metros x L 3,70 metros) temos que A x L = a 10MQ, e entao temos que 1 lata com 3600ml "
								            + "\nde tinta dividido por 10 tera 360ml para cada 1MQ, esse sera o padrao do calculo 360ml = 1MQ, então tem se que Quaisquer(N) metros quadrados x 360ml = a (N) litros de tinta "
								            + "\ne esse resultado dividido por 3600ml sera igual a (N) quantidade de latas de tinta.\n"
								            + "\nPara calcular uma demao: \n"
								            + "\nPara pintar uma demao temos que uma bandeja de tinta tem 1000ml como referencia por demao, e uma lata de tinta tem 3600ml entao temos que uma lata tem 1200ml por demao "
								            + "\nja que 1200ml vs 3 = a 3600ml(3,6L). Uma demao equivale a uma pintura completa de uma parede. Geralmente eh necessario de duas a tres demaos para pintar uma parede.\n");

								}
							});
							btnNewButton_14.setBounds(95, 67, 85, 21);
							panel_7.add(btnNewButton_14);
							
							JButton btnNewButton_15 = new JButton("Sobre");
							btnNewButton_15.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									JOptionPane.showMessageDialog(
											null,"Software:  Paint House - Metragem e Calculo para Pintura Residencial\n"
											+"\nAuthor: PHNO"
											+"\nData Release: 31/10/2024"
											+"\nVersao Codigo: 0.0.0.1v"
											+"\nReplit: @PHNO, @PHREPLIT"
											+"\nE-mail: phreplit@gmail.com");
								}
							});
							btnNewButton_15.setBounds(95, 98, 85, 21);
							panel_7.add(btnNewButton_15);
							
							JButton btnNewButton_16 = new JButton("Limpar Dados");
							btnNewButton_16.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField.setText("");
									textField_1.setText("");
									textField_2.setText("");
									textField_3.setText("");
									textField_4.setText("");
									textField_5.setText("");
									textField_6.setText("");
									textField_7.setText("");
									textField_8.setText("");
									textField_12.setText("");
									textField_15.setText("");
									textField_16.setText("");
									textField_17.setText("");
									textField_18.setText("");
									
								}
							});
							btnNewButton_16.setBounds(81, 129, 112, 21);
							panel_7.add(btnNewButton_16);
							
							JPanel panel_1 = new JPanel();
							panel_1.setBackground(SystemColor.activeCaption);
							panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "2. Calcular Quantidade de Latas por M\u00B2", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
							panel_1.setBounds(290, 10, 264, 282);
							frmPaintHouse.getContentPane().add(panel_1);
							panel_1.setLayout(null);
							
							JLabel lblNewLabel_3 = new JLabel("Digite quantos metros quadrados tem a parede.:");
							lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 9));
							lblNewLabel_3.setBounds(10, 34, 244, 13);
							panel_1.add(lblNewLabel_3);
							
							JLabel lblNewLabel_4 = new JLabel("Resultado - A quantidade de tinta para");
							lblNewLabel_4.setBounds(10, 73, 244, 27);
							panel_1.add(lblNewLabel_4);
							
							JLabel lblNewLabel_5 = new JLabel("Resultado - A quantidade de lata(s) ");
							lblNewLabel_5.setBounds(10, 148, 244, 13);
							panel_1.add(lblNewLabel_5);
							
							textField_3 = new JTextField();
							textField_3.setBounds(10, 55, 180, 19);
							panel_1.add(textField_3);
							textField_3.setColumns(10);
							
							textField_4 = new JTextField();
							textField_4.setBounds(10, 119, 180, 19);
							panel_1.add(textField_4);
							textField_4.setColumns(10);
							
							textField_5 = new JTextField();
							textField_5.setBounds(10, 185, 180, 19);
							panel_1.add(textField_5);
							textField_5.setColumns(10);
							
							JButton btnNewButton_2 = new JButton("Calcular");
							btnNewButton_2.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int var2 = 360;
									double qtdtinta = 3600; 
									int result = Integer.parseInt(textField_3.getText())*(var2);
					                double result2 = result / qtdtinta; 
				                    textField_4.setText(String.valueOf(result));
					                textField_5.setText(String.valueOf(result2));  
								}
							});
							btnNewButton_2.setBounds(10, 214, 85, 21);
							panel_1.add(btnNewButton_2);
							
							JButton btnNewButton_3 = new JButton("Resetar");
							btnNewButton_3.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField_3.setText("");
									textField_4.setText("");
									textField_5.setText("");
								}
							});
							btnNewButton_3.setBounds(105, 214, 85, 21);
							panel_1.add(btnNewButton_3);
							
							JLabel lblNewLabel_7 = new JLabel("pintar (n) M² é de (n) mililitro(s).:");
							lblNewLabel_7.setBounds(10, 96, 244, 13);
							panel_1.add(lblNewLabel_7);
							
							JLabel lblNewLabel_9 = new JLabel("é de (n) lata(s).:");
							lblNewLabel_9.setBounds(10, 162, 180, 13);
							panel_1.add(lblNewLabel_9);
							
							JPanel panel_2 = new JPanel();
							panel_2.setBackground(SystemColor.activeCaption);
							panel_2.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Calculadora Basica", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
							panel_2.setBounds(564, 10, 270, 280);
							frmPaintHouse.getContentPane().add(panel_2);
							panel_2.setLayout(null);
							
							JLabel lblNewLabel_6 = new JLabel("Digite um numero.:");
							lblNewLabel_6.setBounds(10, 33, 180, 13);
							panel_2.add(lblNewLabel_6);
							
							textField_6 = new JTextField();
							textField_6.setBounds(10, 56, 109, 19);
							panel_2.add(textField_6);
							textField_6.setColumns(10);
							
							textField_7 = new JTextField();
							textField_7.setBounds(10, 107, 109, 19);
							panel_2.add(textField_7);
							textField_7.setColumns(10);
							
							textField_8 = new JTextField();
							textField_8.setBounds(10, 160, 109, 19);
							panel_2.add(textField_8);
							textField_8.setColumns(10);
							
							JLabel lblNewLabel_8 = new JLabel("Digite outro numero.:");
							lblNewLabel_8.setBounds(10, 85, 180, 13);
							panel_2.add(lblNewLabel_8);
							
							JLabel lblNewLabel_10 = new JLabel("Resultado.:");
							lblNewLabel_10.setBounds(10, 137, 180, 13);
							panel_2.add(lblNewLabel_10);
							
							JButton btnNewButton_4 = new JButton("Somar");
							btnNewButton_4.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int sum = Integer.parseInt(textField_6.getText())+Integer.parseInt(textField_7.getText());
									textField_8.setText(String.valueOf(sum));
								}
							});
							btnNewButton_4.setBounds(148, 56, 85, 21);
							panel_2.add(btnNewButton_4);
							
							JButton btnNewButton_5 = new JButton("Resetar");
							btnNewButton_5.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									textField_6.setText("");
									textField_7.setText("");
									textField_8.setText("");
									
								}
							});
							btnNewButton_5.setBounds(10, 189, 85, 21);
							panel_2.add(btnNewButton_5);
							
							JButton btnNewButton_6 = new JButton("Subtrair");
							btnNewButton_6.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int sub = Integer.parseInt(textField_6.getText())-Integer.parseInt(textField_7.getText());
									textField_8.setText(String.valueOf(sub));
								}
							});
							btnNewButton_6.setBounds(148, 91, 85, 21);
							panel_2.add(btnNewButton_6);
							
							JButton btnNewButton_7 = new JButton("Dividir");
							btnNewButton_7.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int div = Integer.parseInt(textField_6.getText())/Integer.parseInt(textField_7.getText());
									textField_8.setText(String.valueOf(div));
								}
							});
							btnNewButton_7.setBounds(148, 122, 85, 21);
							panel_2.add(btnNewButton_7);
							
							JButton btnNewButton_12 = new JButton("Multiplicar");
							btnNewButton_12.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									int mult2 = Integer.parseInt(textField_6.getText())*Integer.parseInt(textField_7.getText());
									textField_8.setText(String.valueOf(mult2));  
								}
							});
							btnNewButton_12.setBounds(148, 153, 85, 21);
							panel_2.add(btnNewButton_12);
						}
					}

